export interface GlobalDataSummary{
    country?:string,
    confirmed?:number,
    death?:number,
    recovered?:number,
    active?:number
}